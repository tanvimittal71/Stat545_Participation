#' @title Square the input
#' @param x Vector of numerics
#' @return  Square of vector x
#' @export
square <- function(x) x^2
